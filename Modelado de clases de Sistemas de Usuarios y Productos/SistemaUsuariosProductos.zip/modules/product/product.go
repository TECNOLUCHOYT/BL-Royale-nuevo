package product

type Product struct {
    ID          int
    Nombre      string
    Descripcion string
    Precio      float64
    Disponible  bool
}
